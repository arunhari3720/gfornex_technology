import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence, useMotionTemplate, useMotionValueEvent, useScroll, useTransform } from "motion/react";

/* npm i motion  (framer-motion's new package name) */

const LOGO_FULL = "https://res.cloudinary.com/t8rmmuib/image/upload/v1795523239/fornex-full-logo-transparent.png";
const LOGO_MARK = "https://res.cloudinary.com/t8rmmuib/image/upload/v1795523238/gfornex-logo-transparent.png";

const services = [
  { icon: "</>", title: "Websites & web apps", desc: "Responsive company websites, online stores and business applications built for speed, search visibility and easy management.", tags: ["Corporate & e-commerce sites", "Customer portals & dashboards", "SEO-ready, mobile-first builds"] },
  { icon: "▣", title: "Mobile applications", desc: "Polished Android and iOS apps that give your customers a fast, dependable way to reach your business.", tags: ["Android & iOS development", "Booking, ordering & service apps", "Store submission and updates"] },
  { icon: "☁", title: "Cloud & DevOps", desc: "Secure cloud infrastructure and automated delivery, so your systems stay available, scalable and cost-efficient.", tags: ["Cloud setup and migration", "Automated deployments", "Monitoring, backups & cost control"] },
  { icon: "✳", title: "AI & automation", desc: "Practical AI and workflow automation that removes repetitive work and gives your team time back.", tags: ["Customer support chatbots", "Document and data processing", "Custom system integrations"] },
  { icon: "◇", title: "Cybersecurity", desc: "Security reviews and safeguards that protect your data, your customers and your reputation.", tags: ["Vulnerability assessments", "Secure authentication", "Data protection and backups"] },
  { icon: "✧", title: "UI & UX design", desc: "Clear, modern interfaces designed around how real users think and behave, aligned with your brand.", tags: ["User journeys and research", "Wireframes and prototypes", "Design systems and style guides"] },
];

const steps = [
  ["Discover", "We understand your goals, users and budget, then agree on a clear scope, timeline and quote."],
  ["Design", "You review wireframes and visual designs and approve them before development begins."],
  ["Build", "We build in focused cycles with regular demos, so you can test real features early."],
  ["Launch", "We test, deploy and support your product with monitoring and ongoing improvements."],
];

const reasons = [
  ["Clear scope and pricing", "Every project starts with a written scope, timeline and quote, so there are no surprises later."],
  ["Security by default", "Secure logins, protected data and regular backups are part of every build."],
  ["Plain-language updates", "Regular progress reports in simple terms, without unnecessary technical jargon."],
  ["You own your work", "Source code, designs and accounts are handed over to you, with documentation."],
  ["Support after launch", "Maintenance, monitoring, fixes and new features are available long after go-live."],
  ["Focused attention", "Your project is handled by the people who build it, with one point of contact throughout."],
];

const builds = [
  ["Business websites", "A clear, confident digital presence for your brand."],
  ["Customer applications", "Useful mobile and web experiences that simplify everyday tasks."],
  ["Connected systems", "Dashboards, automation and integrations that bring work together."],
  ["Booking & ordering apps", "Let customers reserve, order and pay without a phone call."],
  ["Support chatbots", "Answer common questions instantly, any time of day."],
];

const samples = [
  ["Company website", "Corporate site with services, enquiry form and SEO set-up."],
  ["Online store", "Catalogue, cart and checkout built for mobile shoppers."],
  ["Booking app", "Customers pick a slot, pay and get reminders."],
  ["Team dashboard", "Live numbers and reports in one secure place."],
];

/* SAMPLE ONLY: replace with real client feedback before launch */
const testimonials = [
  { name: "Client name", role: "Company, City", quote: "Replace this with a real quote from a client about working with Fornex." },
  { name: "Client name", role: "Company, City", quote: "Replace this with a second real client quote about the result." },
  { name: "Client name", role: "Company, City", quote: "Replace this with a third real client quote about support after launch." },
  { name: "Client name", role: "Company, City", quote: "Replace this with a fourth real client quote about communication." },
];

const faqs = [
  ["How long does a project take?", "It depends on scope. A business website typically takes a few weeks, while mobile apps and custom systems take several months. You get a clear timeline after discovery."],
  ["How do you price projects?", "After discovery, we provide a fixed quote broken into milestones, so you know the cost before work begins. Ongoing support is available as a monthly plan."],
  ["Who owns the code and designs?", "You do. Once the project is paid for, the source code, designs and agreed accounts are transferred to you with documentation."],
  ["Can you work with clients outside Madurai?", "Yes. We work remotely with clients across India and abroad through scheduled calls and written progress updates."],
  ["Do you provide support after launch?", "Yes. We offer maintenance, monitoring, security updates and new features after launch."],
];

function Brand() {
  return (
    <a href="#home" className="inline-flex items-center" aria-label="Fornex IT Solutions">
      <img src={LOGO_FULL} alt="Fornex IT Solutions" className="h-9 w-auto" />
    </a>
  );
}

function SectionHeading({ eyebrow, title, desc, center = false, dark = false }) {
  return (
    <div className={`mb-12 max-w-2xl ${center ? "mx-auto text-center" : ""}`}>
      <p className={`mb-3 text-xs font-bold uppercase tracking-[.24em] ${dark ? "text-brand-300" : "text-brand-600"}`}>{eyebrow}</p>
      <h2 className={`font-heading text-3xl font-bold leading-tight tracking-tight sm:text-4xl ${dark ? "text-white" : "text-brand-900"}`}>{title}</h2>
      {desc && <p className={`mt-4 text-base leading-7 sm:text-lg ${dark ? "text-brand-100/75" : "text-slate-600"}`}>{desc}</p>}
    </div>
  );
}

/* 1. Scroll morph hero: a small card opens into the full screen */
function MorphHero() {
  const ref = useRef(null);
  const { scrollYProgress: p } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const top = useTransform(p, [0, 0.7], [56, 0]);
  const side = useTransform(p, [0, 0.7], [26, 0]);
  const bottom = useTransform(p, [0, 0.7], [6, 0]);
  const radius = useTransform(p, [0, 0.7], [48, 0]);
  const clip = useMotionTemplate`inset(${top}% ${side}% ${bottom}% ${side}% round ${radius}px)`;
  const textY = useTransform(p, [0, 0.35], [0, -80]);
  const textO = useTransform(p, [0, 0.3], [1, 0]);
  const inO = useTransform(p, [0.5, 0.78], [0, 1]);
  return (
    <section id="home" ref={ref} className="relative h-[240vh]">
      <div className="sticky top-0 h-screen overflow-hidden bg-gradient-to-b from-brand-50 to-white">
        <motion.div style={{ y: textY, opacity: textO }} className="container-width absolute inset-x-0 top-[15vh] z-10 text-center">
          <h1 className="mx-auto max-w-4xl font-heading text-4xl font-bold leading-[1.12] tracking-[-.05em] text-brand-900 sm:text-6xl lg:text-7xl">
            Technology that moves your <span className="gradient-text">business forward.</span>
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-base leading-7 text-slate-600 sm:text-lg">Websites, mobile apps, cloud systems and automation for growing businesses, from Madurai.</p>
          <a href="#contact" className="mt-7 inline-flex rounded-full bg-brand-700 px-7 py-3.5 text-sm font-bold text-white shadow-xl shadow-brand-200 transition hover:bg-brand-800">Start a project</a>
        </motion.div>
        <motion.div style={{ clipPath: clip }} className="absolute inset-0 grid place-items-center bg-gradient-to-br from-brand-800 via-brand-700 to-brand-900">
          <div className="hero-orb float-slow absolute h-[60vmin] w-[60vmin] rounded-full opacity-60" />
          <motion.div style={{ opacity: inO }} className="relative z-10 px-6 text-center text-white">
            <div className="mx-auto mb-6 grid h-24 w-24 place-items-center rounded-3xl bg-brand-950 p-3 shadow-2xl ring-1 ring-white/20"><img src={LOGO_MARK} alt="" className="h-full w-full object-contain" /></div>
            <h2 className="mx-auto max-w-2xl font-heading text-3xl font-bold leading-tight sm:text-5xl">Web, apps, cloud, AI and security. One team.</h2>
          </motion.div>
          <p className="absolute bottom-6 text-xs font-semibold text-brand-200">Scroll to explore ↓</p>
        </motion.div>
      </div>
    </section>
  );
}

/* 2. Story scroll: words light up as you scroll */
function Word({ w, i, n, p }) {
  const o = useTransform(p, [i / n, (i + 1) / n], [0.15, 1]);
  return <motion.span style={{ opacity: o }} className="mr-[.28em] inline-block">{w}</motion.span>;
}
function StoryScroll() {
  const ref = useRef(null);
  const { scrollYProgress: p } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const words = "Great businesses deserve technology that keeps up. We design, build and support the websites, apps and systems that help customers find you, trust you and take the next step.".split(" ");
  return (
    <section ref={ref} className="relative h-[220vh]">
      <div className="sticky top-0 grid h-screen place-items-center">
        <p className="container-width max-w-4xl font-heading text-3xl font-bold leading-snug tracking-tight text-brand-900 sm:text-5xl">
          {words.map((w, i) => <Word key={i} w={w} i={i} n={words.length} p={p} />)}
        </p>
      </div>
    </section>
  );
}

/* 3. Container scroll: dashboard tilts flat as it arrives */
function TiltDashboard() {
  const ref = useRef(null);
  const { scrollYProgress: p } = useScroll({ target: ref, offset: ["start end", "center center"] });
  const rotateX = useTransform(p, [0, 1], [24, 0]);
  const scale = useTransform(p, [0, 1], [0.88, 1]);
  return (
    <section className="bg-brand-50/70 py-24 sm:py-28">
      <div className="container-width">
        <SectionHeading eyebrow="What you get" title="Everything your business needs online, in one place." center />
        <div ref={ref} style={{ perspective: 1200 }}>
          <motion.div style={{ rotateX, scale }} className="mx-auto max-w-4xl rounded-[2rem] border border-brand-200 bg-brand-900 p-3 shadow-2xl shadow-brand-300 sm:p-5">
            <div className="rounded-2xl bg-white p-5 sm:p-8">
              <div className="mb-5 flex items-center justify-between"><div className="flex gap-1.5"><i className="h-2.5 w-2.5 rounded-full bg-brand-200" /><i className="h-2.5 w-2.5 rounded-full bg-brand-300" /><i className="h-2.5 w-2.5 rounded-full bg-brand-400" /></div><span className="text-xs font-bold text-brand-500">Business overview</span></div>
              <div className="grid gap-3 sm:grid-cols-3">
                {[["Search visibility", "Growing"], ["Site performance", "Optimised"], ["Enquiries", "Rising"]].map(([a, b]) => <div key={a} className="rounded-xl bg-brand-50 p-4"><p className="text-xs text-slate-500">{a}</p><p className="mt-1 font-heading text-2xl font-bold">{b}</p></div>)}
              </div>
              <div className="mt-3 rounded-xl border border-brand-100 p-4">
                <div className="mb-4 flex items-center justify-between"><span className="text-sm font-bold">Digital growth</span><span className="rounded-full bg-brand-100 px-2 py-1 text-[10px] font-bold text-brand-700">Illustrative</span></div>
                <div className="flex h-32 items-end gap-2">{[28, 40, 35, 57, 48, 70, 64, 88, 78, 100].map((h, i) => <div key={i} style={{ height: `${h}%`, animationDelay: `${i * 0.18}s` }} className="live-bar flex-1 rounded-t-md bg-gradient-to-t from-brand-600 to-brand-300" />)}</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

/* 4. Works wheel: services rotate around a wheel as you scroll */
function WheelItem({ s, i, rot, active }) {
  const inner = useTransform(rot, (v) => -v - i * 60);
  return (
    <div className="absolute left-1/2 top-1/2 -ml-8 -mt-8 h-16 w-16 [--r:122px] sm:[--r:205px]" style={{ transform: `rotate(${i * 60}deg) translateY(calc(var(--r) * -1))` }}>
      <motion.div style={{ rotate: inner }} className={`grid h-16 w-16 place-items-center rounded-2xl border font-heading text-xl font-bold shadow-lg transition-colors duration-300 ${active ? "border-brand-700 bg-brand-700 text-white" : "border-brand-200 bg-white text-brand-700"}`}>{s.icon}</motion.div>
    </div>
  );
}
function WorksWheel() {
  const ref = useRef(null);
  const { scrollYProgress: p } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const rot = useTransform(p, [0, 1], [0, -300]);
  const [active, setActive] = useState(0);
  useMotionValueEvent(p, "change", (v) => setActive(Math.min(5, Math.max(0, Math.round(v * 5)))));
  const s = services[active];
  return (
    <section id="services" ref={ref} className="relative h-[420vh]">
      <div className="sticky top-0 flex h-screen items-center">
        <div className="container-width grid items-center gap-8 lg:grid-cols-2">
          <div className="min-h-[300px]">
            <SectionHeading eyebrow="What we do" title="End-to-end digital solutions." />
            <AnimatePresence mode="wait">
              <motion.div key={active} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }} transition={{ duration: 0.25 }}>
                <h3 className="font-heading text-2xl font-bold">{s.title}</h3>
                <p className="mt-3 max-w-md text-sm leading-7 text-slate-600">{s.desc}</p>
                <ul className="mt-4 space-y-2">{s.tags.map((t) => <li key={t} className="flex gap-2 text-sm font-medium text-slate-700"><span className="text-brand-600">✓</span>{t}</li>)}</ul>
                <a href="#contact" className="mt-5 inline-flex text-sm font-bold text-brand-700">Discuss this service ↗</a>
              </motion.div>
            </AnimatePresence>
          </div>
          <div className="relative mx-auto h-[330px] w-[330px] sm:h-[520px] sm:w-[520px]">
            <div className="absolute inset-[13%] rounded-full border border-dashed border-brand-300" />
            <div className="absolute left-1/2 top-1/2 grid h-24 w-24 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-brand-950 p-4 shadow-xl sm:h-32 sm:w-32"><img src={LOGO_MARK} alt="" className="h-full w-full object-contain" /></div>
            <motion.div style={{ rotate: rot }} className="absolute inset-0">
              {services.map((x, i) => <WheelItem key={x.title} s={x} i={i} rot={rot} active={i === active} />)}
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* 5. Scroll stacking cards: process steps pile up */
function StackingProcess() {
  const tones = ["bg-brand-700", "bg-brand-600", "bg-brand-800", "bg-brand-900"];
  return (
    <section id="process" className="bg-brand-900 py-24 text-white sm:py-28">
      <div className="container-width">
        <SectionHeading dark eyebrow="How we work" title="A clear path from idea to launch." desc="A collaborative process that keeps decisions visible and progress predictable." />
        <div className="pb-10">
          {steps.map(([t, d], i) => (
            <div key={t} className="sticky mb-8" style={{ top: `${96 + i * 26}px` }}>
              <div className={`${tones[i]} flex min-h-[220px] flex-col justify-between rounded-3xl border border-white/15 p-7 shadow-2xl sm:p-10`}>
                <span className="font-heading text-5xl font-bold text-brand-200">{i + 1}</span>
                <div><h3 className="font-heading text-2xl font-bold">{t}</h3><p className="mt-2 max-w-xl text-sm leading-7 text-brand-100/80">{d}</p></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* 6. Horizontal scroll gallery */
function HorizontalGallery() {
  const ref = useRef(null);
  const track = useRef(null);
  const [dx, setDx] = useState(0);
  useEffect(() => {
    const f = () => track.current && setDx(Math.max(0, track.current.scrollWidth - window.innerWidth));
    f();
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, []);
  const { scrollYProgress: p } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const x = useTransform(p, [0, 1], [0, -dx]);
  const fills = ["from-brand-200 to-brand-500", "from-brand-400 to-brand-800", "from-brand-100 to-brand-600", "from-brand-300 to-brand-700", "from-brand-500 to-brand-900"];
  return (
    <section ref={ref} className="relative h-[320vh]">
      <div className="sticky top-0 flex h-screen flex-col justify-center overflow-hidden">
        <div className="container-width"><SectionHeading eyebrow="What we build" title="Digital experiences made for real-world work." /></div>
        <motion.div ref={track} style={{ x }} className="flex w-max gap-6 px-[max(24px,calc((100vw-1160px)/2))]">
          {builds.map(([t, d], i) => (
            <div key={t} className="w-[78vw] shrink-0 overflow-hidden rounded-3xl border border-brand-100 bg-white shadow-lg shadow-brand-100 sm:w-[380px]">
              <div className={`relative grid h-48 place-items-center bg-gradient-to-br ${fills[i]}`}><div className="grid-pattern absolute inset-0 opacity-60" /><span className="relative font-heading text-6xl font-extrabold text-white/60">{i + 1}</span></div>
              <div className="p-6"><h3 className="font-heading text-lg font-bold">{t}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{d}</p></div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* 7. Zoom parallax */
function ZoomParallax() {
  const ref = useRef(null);
  const { scrollYProgress: p } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const scales = [useTransform(p, [0, 1], [1, 4]), useTransform(p, [0, 1], [1, 5]), useTransform(p, [0, 1], [1, 6]), useTransform(p, [0, 1], [1, 5]), useTransform(p, [0, 1], [1, 6]), useTransform(p, [0, 1], [1, 8]), useTransform(p, [0, 1], [1, 9])];
  const tiles = [
    ["h-[25vh] w-[25vw]", "Madurai"], ["-top-[30vh] left-[5vw] h-[30vh] w-[35vw]", "Web & apps"], ["-top-[10vh] -left-[25vw] h-[45vh] w-[20vw]", "Cloud"],
    ["left-[27.5vw] h-[25vh] w-[25vw]", "AI"], ["top-[27.5vh] left-[5vw] h-[25vh] w-[20vw]", "Security"], ["top-[27.5vh] -left-[22.5vw] h-[25vh] w-[30vw]", "UI & UX"], ["top-[22.5vh] left-[25vw] h-[15vh] w-[15vw]", "Support"],
  ];
  const fills = ["from-brand-700 to-brand-900", "from-brand-300 to-brand-500", "from-brand-500 to-brand-700", "from-brand-200 to-brand-400", "from-brand-600 to-brand-800", "from-brand-400 to-brand-600", "from-brand-300 to-brand-600"];
  return (
    <section ref={ref} className="relative h-[300vh]">
      <div className="sticky top-0 h-screen overflow-hidden">
        {tiles.map(([cls, label], i) => (
          <motion.div key={label} style={{ scale: scales[i] }} className="absolute top-0 flex h-full w-full items-center justify-center">
            <div className={`relative grid place-items-center rounded-xl bg-gradient-to-br ${fills[i]} ${cls}`}>
              {i === 0 ? <div className="text-center text-white"><p className="font-heading text-xs font-bold sm:text-lg">Madurai</p><p className="text-[8px] sm:text-xs">Tamil Nadu</p></div> : <span className="px-1 text-center font-heading text-[9px] font-bold text-white/90 sm:text-sm">{label}</span>}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* 8. Bento with live diagrams */
const diagrams = [
  <svg key="a" viewBox="0 0 200 50" className="h-16 w-full text-brand-600"><path pathLength="1" className="draw" d="M10 40 H70 V15 H130 V30 H190" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />{[10, 70, 130, 190].map((x) => <circle key={x} cx={x} cy={x === 10 ? 40 : x === 70 ? 15 : x === 130 ? 15 : 30} r="4" fill="currentColor" />)}</svg>,
  <svg key="b" viewBox="0 0 100 60" className="h-16 w-full text-brand-600"><circle className="ring" cx="50" cy="30" r="10" fill="none" stroke="currentColor" strokeWidth="2" /><circle className="ring" style={{ animationDelay: "1s" }} cx="50" cy="30" r="10" fill="none" stroke="currentColor" strokeWidth="2" /><circle cx="50" cy="30" r="9" fill="currentColor" /><path d="M46 30 l3 3 l6 -6" stroke="white" strokeWidth="2" fill="none" strokeLinecap="round" /></svg>,
  <div key="c" className="space-y-2 py-1">{["w-2/3", "w-1/2 ml-auto", "w-3/5"].map((w, i) => <div key={i} style={{ animationDelay: `${i * 0.7}s` }} className={`typing h-3 rounded-full ${i === 1 ? "bg-brand-600" : "bg-brand-200"} ${w}`} />)}</div>,
  <div key="d" className="relative flex h-16 items-center justify-between px-2"><div className="h-9 w-9 rounded-lg bg-brand-200" /><div className="absolute left-12 right-12 top-1/2 h-px bg-brand-300" /><i className="travel absolute left-12 top-1/2 h-2.5 w-2.5 -translate-y-1/2 rounded-full bg-brand-600" /><div className="h-9 w-9 rounded-lg bg-brand-600" /></div>,
  <svg key="e" viewBox="0 0 200 50" className="h-16 w-full text-brand-600"><path pathLength="1" className="draw" d="M0 25 H40 L50 5 L60 45 L70 25 H110 L120 10 L130 40 L140 25 H200" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg>,
  <svg key="f" viewBox="0 0 120 60" className="h-16 w-full text-brand-600"><path d="M20 30 H60 M60 30 L100 14 M60 30 L100 46" stroke="currentColor" strokeWidth="1.5" opacity=".4" />{[[20, 30], [60, 30], [100, 14], [100, 46]].map(([x, y], i) => <circle key={i} className="ring" style={{ animationDelay: `${i * 0.5}s` }} cx={x} cy={y} r="6" fill="currentColor" />)}</svg>,
];
function Bento() {
  const spans = ["lg:col-span-2", "", "", "", "lg:col-span-2", ""];
  return (
    <section id="why" className="bg-brand-50/70 py-24 sm:py-28">
      <div className="container-width">
        <SectionHeading eyebrow="Why Fornex" title="Good technology. Clear communication. No surprises." />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {reasons.map(([t, d], i) => (
            <motion.div key={t} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }} transition={{ delay: (i % 3) * 0.08 }} className={`rounded-3xl border border-brand-100 bg-white p-6 ${spans[i]}`}>
              <div className="mb-5 rounded-2xl bg-brand-50 px-4 py-3">{diagrams[i]}</div>
              <h3 className="font-heading font-bold">{t}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-600">{d}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* 9. Flipping deck of sample layouts (swap the mock for <img> screenshots when you have them) */
function FlipDeck() {
  const [i, setI] = useState(0);
  const fills = ["from-brand-200 to-brand-500", "from-brand-300 to-brand-700", "from-brand-100 to-brand-600", "from-brand-400 to-brand-800"];
  const [t, d] = samples[i];
  return (
    <section className="py-24 sm:py-28">
      <div className="container-width grid items-center gap-12 lg:grid-cols-2">
        <div>
          <SectionHeading eyebrow="Sample layouts" title="The kind of work we build." desc="Flip through example layouts. Real project screenshots can replace these." />
          <div className="flex gap-3">
            <button onClick={() => setI((i + samples.length - 1) % samples.length)} className="rounded-full border border-brand-200 px-5 py-3 text-sm font-bold text-brand-800 hover:bg-brand-50">Previous</button>
            <button onClick={() => setI((i + 1) % samples.length)} className="rounded-full bg-brand-700 px-5 py-3 text-sm font-bold text-white hover:bg-brand-800">Next</button>
          </div>
        </div>
        <div className="relative mx-auto w-full max-w-md" style={{ perspective: 1400 }}>
          <div className="absolute inset-x-6 top-4 h-full rounded-3xl bg-brand-200/70" />
          <div className="absolute inset-x-3 top-2 h-full rounded-3xl bg-brand-300/70" />
          <AnimatePresence mode="wait">
            <motion.div key={i} initial={{ rotateY: -90, opacity: 0 }} animate={{ rotateY: 0, opacity: 1 }} exit={{ rotateY: 90, opacity: 0 }} transition={{ duration: 0.4 }} className="relative overflow-hidden rounded-3xl border border-brand-100 bg-white shadow-2xl shadow-brand-200">
              <div className="flex items-center gap-1.5 border-b border-brand-100 px-4 py-3"><i className="h-2.5 w-2.5 rounded-full bg-brand-200" /><i className="h-2.5 w-2.5 rounded-full bg-brand-300" /><i className="h-2.5 w-2.5 rounded-full bg-brand-400" /><span className="ml-3 h-4 flex-1 rounded-full bg-brand-50" /></div>
              <div className={`h-52 bg-gradient-to-br ${fills[i]} p-6`}><div className="h-3 w-1/3 rounded bg-white/70" /><div className="mt-4 h-8 w-2/3 rounded bg-white/50" /><div className="mt-6 grid grid-cols-3 gap-2"><i className="h-14 rounded bg-white/40" /><i className="h-14 rounded bg-white/55" /><i className="h-14 rounded bg-white/70" /></div></div>
              <div className="p-6"><h3 className="font-heading text-lg font-bold">{t}</h3><p className="mt-1 text-sm text-slate-600">{d}</p></div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

/* 10. Circular testimonials */
function CircularTestimonials() {
  const [a, setA] = useState(0);
  const q = testimonials[a];
  const n = testimonials.length;
  return (
    <section className="bg-brand-50/70 py-24 sm:py-28">
      <div className="container-width">
        <SectionHeading center eyebrow="Client feedback" title="What working with us feels like." />
        <div className="relative mx-auto h-[420px] w-full max-w-[460px] sm:h-[480px] sm:max-w-[520px]">
          <div className="absolute inset-[8%] rounded-full border border-dashed border-brand-300" />
          {testimonials.map((t, i) => (
            <button key={i} onClick={() => setA(i)} aria-label={`Show feedback ${i + 1}`} className="absolute left-1/2 top-1/2 -ml-7 -mt-7 h-14 w-14 [--r:175px] sm:[--r:205px]" style={{ transform: `rotate(${(360 / n) * i}deg) translateY(calc(var(--r) * -1)) rotate(${-(360 / n) * i}deg)` }}>
              <span className={`grid h-14 w-14 place-items-center rounded-full border-2 font-heading font-bold transition ${i === a ? "scale-110 border-brand-700 bg-brand-700 text-white" : "border-brand-200 bg-white text-brand-700"}`}>{t.name[0]}</span>
            </button>
          ))}
          <div className="absolute inset-[22%] grid place-items-center text-center">
            <AnimatePresence mode="wait">
              <motion.div key={a} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }}>
                <p className="text-sm leading-6 text-slate-700 sm:text-base">“{q.quote}”</p>
                <p className="mt-3 font-heading text-sm font-bold">{q.name}</p>
                <p className="text-xs text-slate-500">{q.role}</p>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState(0);
  const [selected, setSelected] = useState([]);
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const nav = [["Services", "#services"], ["Process", "#process"], ["Why Fornex", "#why"], ["FAQ", "#faq"]];
  const toggleService = (name) => setSelected((old) => (old.includes(name) ? old.filter((x) => x !== name) : [...old, name]));

  const submitForm = (e) => {
    e.preventDefault();
    const body = `Name: ${form.name}\nEmail: ${form.email}\nServices: ${selected.join(", ") || "Not specified"}\n\n${form.message}`;
    window.location.href = `mailto:gfornex.official@gmail.com?subject=${encodeURIComponent(`New project enquiry from ${form.name}`)}&body=${encodeURIComponent(body)}`;
  };

  const field = "mt-2 w-full rounded-xl border border-brand-200 bg-brand-50/60 px-4 py-3 font-normal outline-none transition focus:border-brand-500 focus:ring-4 focus:ring-brand-100";

  return (
    <div className="overflow-x-clip bg-white text-brand-900">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-brand-950/90 backdrop-blur-xl">
        <div className="container-width flex h-[76px] items-center justify-between">
          <Brand />
          <nav className="hidden items-center gap-8 md:flex">
            {nav.map(([label, href]) => <a key={label} href={href} className="text-sm font-semibold text-brand-100 transition hover:text-white">{label}</a>)}
            <a href="#contact" className="rounded-full bg-brand-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-brand-900/40 transition hover:bg-brand-400">Let’s talk</a>
          </nav>
          <button onClick={() => setMenuOpen(!menuOpen)} className="rounded-xl border border-white/30 px-3 py-2 text-sm font-bold text-white md:hidden" aria-label="Toggle navigation">{menuOpen ? "Close" : "Menu"}</button>
        </div>
        {menuOpen && <nav className="container-width flex flex-col gap-1 pb-5 md:hidden">{[...nav, ["Contact", "#contact"]].map(([label, href]) => <a onClick={() => setMenuOpen(false)} key={label} href={href} className="rounded-xl px-3 py-3 font-semibold text-brand-100 hover:bg-white/10">{label}</a>)}</nav>}
      </header>

      <main>
        <MorphHero />
        <StoryScroll />
        <TiltDashboard />
        <WorksWheel />
        <StackingProcess />
        <HorizontalGallery />
        <ZoomParallax />
        <Bento />
        <FlipDeck />
        <CircularTestimonials />

        <section id="faq" className="py-24 sm:py-28"><div className="container-width max-w-4xl"><SectionHeading eyebrow="FAQ" title="A few things you might want to know." desc="Still have a question? Send us a message and we’ll be happy to help." center />
          <div className="divide-y divide-brand-200 border-y border-brand-200">{faqs.map(([q, a], i) => <div key={q} className="py-5"><button onClick={() => setOpenFaq(openFaq === i ? -1 : i)} className="flex w-full items-center justify-between gap-5 text-left font-heading text-base font-bold text-brand-900 sm:text-lg"><span>{q}</span><span className={`text-xl text-brand-600 transition ${openFaq === i ? "rotate-180" : ""}`}>⌄</span></button>{openFaq === i && <p className="max-w-3xl pt-4 text-sm leading-7 text-slate-600">{a}</p>}</div>)}</div>
        </div></section>

        <section id="contact" className="bg-brand-50/70 py-24 sm:py-28"><div className="container-width grid gap-12 lg:grid-cols-[.85fr_1.15fr]">
          <div><SectionHeading eyebrow="Start a conversation" title="Let’s discuss your project." desc="Tell us what you’re planning. We’ll get back to you with questions and suggested next steps." />
            <a href="mailto:gfornex.official@gmail.com" className="inline-flex items-center gap-3 text-base font-bold text-brand-700 hover:text-brand-900"><span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-100">✉</span>gfornex.official@gmail.com</a>
            <p className="mt-5 text-sm text-slate-500">Madurai, Tamil Nadu, India</p></div>
          <form onSubmit={submitForm} className="rounded-3xl border border-brand-100 bg-white p-6 shadow-xl shadow-brand-100 sm:p-8">
            <div className="grid gap-5 sm:grid-cols-2">
              <label className="text-sm font-bold text-brand-900">Your name<input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={field} placeholder="Enter your name" /></label>
              <label className="text-sm font-bold text-brand-900">Your email<input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={field} placeholder="you@example.com" /></label>
            </div>
            <div className="mt-6"><p className="mb-3 text-sm font-bold">What do you need?</p><div className="flex flex-wrap gap-2">{services.map((s) => <button type="button" key={s.title} onClick={() => toggleService(s.title)} className={`rounded-full border px-3.5 py-2 text-xs font-semibold transition ${selected.includes(s.title) ? "border-brand-700 bg-brand-700 text-white" : "border-brand-200 bg-white text-slate-600 hover:border-brand-400 hover:bg-brand-50"}`}>{s.title}</button>)}</div></div>
            <label className="mt-6 block text-sm font-bold text-brand-900">Tell us about your project<textarea required rows="4" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className={`${field} resize-y`} placeholder="A little about your idea, goals and timeline..." /></label>
            <button type="submit" className="mt-6 inline-flex items-center rounded-full bg-brand-700 px-7 py-3.5 text-sm font-bold text-white shadow-lg shadow-brand-200 transition hover:bg-brand-800">Send enquiry</button>
            <p className="mt-3 text-xs text-slate-400">This opens your default email app with your enquiry prepared.</p>
          </form>
        </div></section>
      </main>

      <footer className="bg-brand-900 py-10 text-white"><div className="container-width flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-center"><div><Brand /><p className="mt-3 text-xs text-brand-200/65">Technology that moves your business forward.</p></div><div className="text-xs text-brand-200/65">© {new Date().getFullYear()} Fornex. All rights reserved. Madurai, Tamil Nadu</div></div></footer>
    </div>
  );
}