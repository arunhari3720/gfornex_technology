import { useState } from "react";

const services = [
  { icon: "</>", title: "Websites & web apps", desc: "Responsive company websites, online stores and business applications built for speed, search visibility and easy management.", tags: ["Corporate & e-commerce sites", "Customer portals & dashboards", "SEO-ready, mobile-first builds"] },
  { icon: "▣", title: "Mobile applications", desc: "Polished Android and iOS apps that give your customers a fast, dependable way to reach your business.", tags: ["Android & iOS development", "Booking, ordering & service apps", "Store submission and updates"] },
  { icon: "☁", title: "Cloud & DevOps", desc: "Secure cloud infrastructure and automated delivery, so your systems stay available, scalable and cost-efficient.", tags: ["Cloud setup and migration", "Automated deployments", "Monitoring, backups & cost control"] },
  { icon: "✳", title: "AI & automation", desc: "Practical AI and workflow automation that removes repetitive work and gives your team time back.", tags: ["Customer support chatbots", "Document and data processing", "Custom system integrations"] },
  { icon: "◇", title: "Cybersecurity", desc: "Security reviews and safeguards that protect your data, your customers and your reputation.", tags: ["Vulnerability assessments", "Secure authentication", "Data protection and backups"] },
  { icon: "✧", title: "UI & UX design", desc: "Clear, modern interfaces designed around how real users think and behave, aligned with your brand.", tags: ["User journeys and research", "Wireframes and prototypes", "Design systems and style guides"] },
];

const steps = [
  ["01", "Discover", "We understand your goals, users and budget, then agree on a clear scope, timeline and quote."],
  ["02", "Design", "You review wireframes and visual designs and approve them before development begins."],
  ["03", "Build", "We build in focused cycles with regular demos, so you can test real features early."],
  ["04", "Launch", "We test, deploy and support your product with monitoring and ongoing improvements."],
];

const reasons = [
  ["Clear scope and pricing", "Every project starts with a written scope, timeline and quote, so there are no surprises later."],
  ["Focused attention", "Your project is handled by the people who build it, with one point of contact throughout."],
  ["Plain-language updates", "Regular progress reports in simple terms, without unnecessary technical jargon."],
  ["You own your work", "Source code, designs and accounts are handed over to you, with documentation."],
  ["Security by default", "Secure logins, protected data and regular backups are part of every build."],
  ["Support after launch", "Maintenance, monitoring, fixes and new features are available long after go-live."],
];

const faqs = [
  ["How long does a project take?", "It depends on scope. A business website typically takes a few weeks, while mobile apps and custom systems take several months. You get a clear timeline after discovery."],
  ["How do you price projects?", "After discovery, we provide a fixed quote broken into milestones, so you know the cost before work begins. Ongoing support is available as a monthly plan."],
  ["Who owns the code and designs?", "You do. Once the project is paid for, the source code, designs and agreed accounts are transferred to you with documentation."],
  ["Can you work with clients outside Madurai?", "Yes. We work remotely with clients across India and abroad through scheduled calls and written progress updates."],
  ["Do you provide support after launch?", "Yes. We offer maintenance, monitoring, security updates and new features after launch."],
];

function Brand({ light = false }) {
  return (
    <a href="#home" className={`inline-flex items-center gap-2 font-heading text-2xl font-extrabold tracking-tight ${light ? "text-white" : "text-lavender-900"}`}>
      <span className="grid h-9 w-9 -skew-x-12 place-items-center rounded-lg bg-gradient-to-br from-lavender-400 via-lavender-600 to-lavender-800 text-xl text-white shadow-lg">F</span>
      FORNEX<span className={`ml-1 mt-3 text-[9px] font-semibold tracking-[.24em] ${light ? "text-lavender-200" : "text-lavender-500"}`}>IT</span>
    </a>
  );
}

function SectionHeading({ eyebrow, title, desc, center = false }) {
  return (
    <div className={`mb-12 max-w-2xl ${center ? "mx-auto text-center" : ""}`}>
      <p className="mb-3 text-xs font-bold uppercase tracking-[.24em] text-lavender-600">{eyebrow}</p>
      <h2 className="font-heading text-3xl font-bold leading-tight tracking-tight text-lavender-900 sm:text-4xl">{title}</h2>
      {desc && <p className="mt-4 text-base leading-7 text-slate-600 sm:text-lg">{desc}</p>}
    </div>
  );
}

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState(0);
  const [selected, setSelected] = useState([]);
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const nav = [["Services", "#services"], ["Process", "#process"], ["Why Fornex", "#why"], ["FAQ", "#faq"]];
  const toggleService = (name) => setSelected((old) => old.includes(name) ? old.filter((x) => x !== name) : [...old, name]);

  const submitForm = (e) => {
    e.preventDefault();
    const body = `Name: ${form.name}\nEmail: ${form.email}\nServices: ${selected.join(", ") || "Not specified"}\n\n${form.message}`;
    window.location.href = `mailto:gfornex.official@gmail.com?subject=${encodeURIComponent(`New project enquiry from ${form.name}`)}&body=${encodeURIComponent(body)}`;
  };

  return (
    <div className="overflow-hidden bg-white text-lavender-900">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-lavender-100/80 bg-white/85 backdrop-blur-xl">
        <div className="container-width flex h-[76px] items-center justify-between">
          <Brand />
          <nav className="hidden items-center gap-8 md:flex">
            {nav.map(([label, href]) => <a key={label} href={href} className="text-sm font-semibold text-slate-600 transition hover:text-lavender-700">{label}</a>)}
            <a href="#contact" className="rounded-full bg-lavender-700 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-lavender-200 transition hover:-translate-y-0.5 hover:bg-lavender-800">Let’s talk ↗</a>
          </nav>
          <button onClick={() => setMenuOpen(!menuOpen)} className="rounded-xl border border-lavender-200 px-3 py-2 text-sm font-bold text-lavender-800 md:hidden" aria-label="Toggle navigation">{menuOpen ? "Close" : "Menu"}</button>
        </div>
        {menuOpen && <nav className="container-width flex flex-col gap-1 pb-5 md:hidden">{[...nav, ["Contact", "#contact"]].map(([label, href]) => <a onClick={() => setMenuOpen(false)} key={label} href={href} className="rounded-xl px-3 py-3 font-semibold text-slate-700 hover:bg-lavender-50">{label}</a>)}</nav>}
      </header>

      <main>
        <section id="home" className="relative flex min-h-[760px] items-center pb-20 pt-32 sm:min-h-[820px]">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_75%_35%,rgba(216,200,240,.34),transparent_38%),linear-gradient(180deg,#FAF8FF_0%,#FFFFFF_78%)]" />
          <div className="pointer-events-none absolute -right-32 top-28 h-[34rem] w-[34rem] rounded-full bg-lavender-200/30 blur-3xl" />
          <div className="container-width relative grid items-center gap-12 lg:grid-cols-[1.05fr_.95fr]">
            <div className="max-w-2xl">
              <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-lavender-200 bg-white/80 px-4 py-2 text-xs font-bold tracking-wide text-lavender-700 shadow-sm"><span className="h-2 w-2 rounded-full bg-lavender-500" /> IT SOLUTIONS FROM MADURAI</div>
              <h1 className="font-heading text-5xl font-bold leading-[1.12] tracking-[-.055em] text-lavender-900 sm:text-6xl lg:text-[4.35rem]">Technology that moves your <span className="gradient-text">business forward.</span></h1>
              <p className="mt-7 max-w-xl text-lg leading-8 text-slate-600">We design, build and support modern websites, mobile apps, cloud systems and intelligent automation for growing businesses.</p>
              <div className="mt-9 flex flex-wrap gap-3">
                <a href="#contact" className="rounded-full bg-lavender-700 px-7 py-4 text-sm font-bold text-white shadow-xl shadow-lavender-200 transition hover:-translate-y-1 hover:bg-lavender-800">Start a project <span className="ml-2">→</span></a>
                <a href="#services" className="rounded-full border border-lavender-200 bg-white/80 px-7 py-4 text-sm font-bold text-lavender-800 transition hover:border-lavender-400 hover:bg-lavender-50">Explore services</a>
              </div>
              <div className="mt-12 flex flex-wrap gap-x-8 gap-y-4 border-t border-lavender-200/80 pt-7">
                {[["End-to-end", "Digital delivery"], ["Built around you", "Clear communication"], ["Long-term", "Technical support"]].map(([a,b]) => <div key={a}><p className="font-heading text-sm font-bold text-lavender-900">{a}</p><p className="mt-1 text-xs text-slate-500">{b}</p></div>)}
              </div>
            </div>

            <div className="relative mx-auto flex aspect-square w-full max-w-[520px] items-center justify-center">
              <div className="absolute inset-[7%] rounded-full border border-lavender-200/80" />
              <div className="orbit absolute inset-[15%] rotate-[-24deg]" />
              <div className="orbit absolute inset-[25%] rotate-[35deg]" />
              <div className="hero-orb float-slow absolute inset-[15%] rounded-full" />
              <div className="relative z-10 grid h-40 w-40 place-items-center rounded-[2.5rem] border border-white/80 bg-white/65 shadow-[0_25px_90px_-28px_rgba(114,83,166,.55)] backdrop-blur-xl sm:h-48 sm:w-48">
                <div className="text-center"><div className="mx-auto mb-2 grid h-14 w-14 -skew-x-12 place-items-center rounded-2xl bg-gradient-to-br from-lavender-400 to-lavender-800 font-heading text-4xl font-extrabold text-white shadow-lg">F</div><p className="font-heading text-lg font-bold tracking-tight">FORNEX</p><p className="text-[9px] font-bold tracking-[.3em] text-lavender-500">IT SOLUTIONS</p></div>
              </div>
              {[["Web & Apps","top-[13%] left-[8%]"],["Cloud","right-[2%] top-[30%]"],["AI Automation","bottom-[15%] right-[5%]"],["Security","bottom-[12%] left-[7%]"]].map(([label,pos]) => <div key={label} className={`absolute ${pos} z-20 rounded-2xl border border-white/90 bg-white/85 px-3 py-2.5 text-xs font-bold text-lavender-800 shadow-xl shadow-lavender-100 backdrop-blur-md`}>{label}</div>)}
              <div className="pulse-soft absolute right-[17%] top-[9%] h-5 w-5 rounded-full bg-lavender-400/60 blur-[1px]" />
            </div>
          </div>
        </section>

        <section className="border-y border-lavender-100 bg-lavender-50/70 py-7">
          <div className="container-width grid grid-cols-2 gap-6 text-center sm:grid-cols-4">
            {[["01","One accountable team"],["02","Clear milestones"],["03","Modern technology"],["04","Ongoing support"]].map(([n,t]) => <div key={n} className="flex items-center justify-center gap-3"><span className="font-heading text-sm font-bold text-lavender-500">{n}</span><span className="text-xs font-semibold text-slate-600 sm:text-sm">{t}</span></div>)}
          </div>
        </section>

        <section className="py-24 sm:py-28">
          <div className="container-width grid items-center gap-14 lg:grid-cols-2">
            <div><SectionHeading eyebrow="The opportunity" title="Great businesses deserve technology that keeps up." desc="A strong product experience helps customers discover you, understand your value and take the next step with confidence." />
              <div className="space-y-5">{[["Be easier to find","Search-ready experiences and thoughtful digital presence."],["Turn visits into enquiries","Clear journeys that make it simple for customers to act."],["Keep operations moving","Connected systems, automation and reliable infrastructure."]].map(([a,b],i) => <div className="flex gap-4" key={a}><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-lavender-100 font-heading font-bold text-lavender-700">0{i+1}</div><div><h3 className="font-heading font-bold">{a}</h3><p className="mt-1 text-sm leading-6 text-slate-600">{b}</p></div></div>)}</div>
            </div>
            <div className="relative rounded-[2rem] border border-lavender-100 bg-gradient-to-br from-lavender-50 via-white to-lavender-100 p-6 shadow-xl shadow-lavender-100 sm:p-9">
              <div className="relative rounded-2xl border border-white bg-white/90 p-5 shadow-sm">
                <div className="mb-5 flex items-center justify-between"><div className="flex gap-1.5"><i className="h-2.5 w-2.5 rounded-full bg-lavender-200"/><i className="h-2.5 w-2.5 rounded-full bg-lavender-300"/><i className="h-2.5 w-2.5 rounded-full bg-lavender-400"/></div><span className="text-[10px] font-bold uppercase tracking-widest text-lavender-500">Business overview</span></div>
                <div className="grid grid-cols-2 gap-3"><div className="rounded-xl bg-lavender-50 p-4"><p className="mb-4 text-xl text-lavender-600">⌕</p><p className="text-xs text-slate-500">Search visibility</p><p className="mt-1 font-heading text-2xl font-bold">Growing</p></div><div className="rounded-xl bg-lavender-50 p-4"><p className="mb-4 text-xl text-lavender-600">↗</p><p className="text-xs text-slate-500">Site performance</p><p className="mt-1 font-heading text-2xl font-bold">Optimised</p></div></div>
                <div className="mt-3 rounded-xl border border-lavender-100 p-4"><div className="mb-4 flex items-center justify-between"><span className="text-sm font-bold">Digital growth</span><span className="rounded-full bg-lavender-100 px-2 py-1 text-[10px] font-bold text-lavender-700">Illustrative</span></div><div className="flex h-28 items-end gap-2">{[28,40,35,57,48,70,64,88,78,100].map((h,i)=><div key={i} style={{height:`${h}%`}} className="flex-1 rounded-t-md bg-gradient-to-t from-lavender-500 to-lavender-300"/>)}</div></div>
              </div>
            </div>
          </div>
        </section>

        <section id="services" className="bg-lavender-50/65 py-24 sm:py-28">
          <div className="container-width"><SectionHeading eyebrow="What we do" title="End-to-end digital solutions." desc="From the first idea to long-term support, one team to design, develop and improve your digital systems." />
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{services.map((s)=><article key={s.title} className="group rounded-3xl border border-lavender-100 bg-white p-7 shadow-sm transition duration-300 hover:-translate-y-1 hover:border-lavender-300 hover:shadow-xl hover:shadow-lavender-100"><div className="mb-6 grid h-12 w-12 place-items-center rounded-2xl bg-lavender-100 font-heading text-lg font-bold text-lavender-700 transition group-hover:bg-lavender-700 group-hover:text-white">{s.icon}</div><h3 className="font-heading text-xl font-bold">{s.title}</h3><p className="mt-3 text-sm leading-7 text-slate-600">{s.desc}</p><ul className="mt-5 space-y-2">{s.tags.map(t=><li key={t} className="flex items-start gap-2 text-xs font-medium text-slate-600"><span className="text-lavender-600">✓</span>{t}</li>)}</ul><div className="mt-7 h-px bg-lavender-100"/><a href="#contact" className="mt-5 inline-flex items-center text-sm font-bold text-lavender-700">Discuss this service ↗</a></article>)}</div>
          </div>
        </section>

        <section id="process" className="relative overflow-hidden bg-lavender-900 py-24 text-white sm:py-28">
          <div className="pointer-events-none absolute -right-24 -top-32 h-96 w-96 rounded-full bg-lavender-700/30 blur-3xl"/>
          <div className="container-width relative"><SectionHeading eyebrow="How we work" title="A clear path from idea to launch." desc="A collaborative process that keeps decisions visible and progress predictable." />
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">{steps.map(([n,t,d])=><div key={n} className="border-t border-lavender-700/70 pt-6"><span className="font-heading text-4xl font-bold text-lavender-300">{n}</span><h3 className="mt-5 font-heading text-xl font-bold">{t}</h3><p className="mt-3 text-sm leading-7 text-lavender-100/70">{d}</p></div>)}</div>
          </div>
        </section>

        <section className="py-24 sm:py-28"><div className="container-width"><SectionHeading eyebrow="What we build" title="Digital experiences made for real-world work." desc="Flexible solutions for the way your customers and teams actually work." center/>
          <div className="grid gap-5 md:grid-cols-3">{[["Business websites","A clear, confident digital presence for your brand."],["Customer applications","Useful mobile and web experiences that simplify everyday tasks."],["Connected systems","Dashboards, automation and integrations that bring work together."]].map(([t,d],i)=><div key={t} className="group overflow-hidden rounded-3xl border border-lavender-100 bg-white shadow-lg shadow-lavender-100/70"><div className={`relative grid h-56 place-items-center overflow-hidden ${i===0?"bg-gradient-to-br from-lavender-200 to-lavender-500":i===1?"bg-gradient-to-br from-lavender-400 to-lavender-800":"bg-gradient-to-br from-lavender-100 to-lavender-600"}`}><div className="grid-pattern absolute inset-0 opacity-60"/><div className="relative grid h-28 w-40 -rotate-6 place-items-center rounded-2xl border border-white/70 bg-white/75 shadow-xl backdrop-blur"><div className="w-4/5 space-y-2"><div className="h-2 w-1/3 rounded bg-lavender-300"/><div className="h-12 rounded-lg bg-gradient-to-r from-lavender-200 to-lavender-400"/><div className="grid grid-cols-3 gap-1"><i className="h-5 rounded bg-lavender-100"/><i className="h-5 rounded bg-lavender-200"/><i className="h-5 rounded bg-lavender-300"/></div></div></div><span className="absolute bottom-4 right-5 font-heading text-5xl font-extrabold text-white/40">0{i+1}</span></div><div className="p-6"><h3 className="font-heading text-lg font-bold">{t}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{d}</p></div></div>)}</div>
        </div></section>

        <section id="why" className="bg-lavender-50/70 py-24 sm:py-28"><div className="container-width grid gap-12 lg:grid-cols-[.8fr_1.2fr]"><div><SectionHeading eyebrow="Why Fornex" title="Good technology. Clear communication. No surprises." desc="We believe the best digital partnerships are built on trust, ownership and steady delivery."/><a href="#contact" className="inline-flex items-center rounded-full bg-lavender-700 px-6 py-3.5 text-sm font-bold text-white transition hover:bg-lavender-800">Work with us →</a></div><div className="grid gap-3 sm:grid-cols-2">{reasons.map(([t,d],i)=><div key={t} className="rounded-2xl border border-lavender-100 bg-white p-5"><div className="mb-4 flex h-9 w-9 items-center justify-center rounded-xl bg-lavender-100 font-heading text-sm font-bold text-lavender-700">0{i+1}</div><h3 className="font-heading font-bold">{t}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{d}</p></div>)}</div></div></section>

        <section className="py-24 sm:py-28"><div className="container-width grid items-center gap-12 lg:grid-cols-2"><div><SectionHeading eyebrow="From Madurai, everywhere" title="Local roots. A wider outlook." desc="Based in Madurai, Tamil Nadu, we work with startups, small businesses and growing companies across India and overseas. Remote collaboration, clear updates and thoughtful delivery keep every project moving."/><div className="flex flex-wrap gap-3"><span className="rounded-full bg-lavender-50 px-4 py-2 text-sm font-semibold text-lavender-800">⌖ Madurai, Tamil Nadu</span><span className="rounded-full bg-lavender-50 px-4 py-2 text-sm font-semibold text-lavender-800">◎ Serving globally</span></div></div><div className="relative overflow-hidden rounded-[2rem] bg-lavender-900 p-8 text-white sm:p-10"><div className="absolute -right-12 -top-12 h-56 w-56 rounded-full border border-lavender-400/30"/><div className="absolute -right-2 top-0 h-40 w-40 rounded-full border border-lavender-400/20"/><div className="relative"><div className="mb-10 flex items-center justify-between"><Brand light/><span className="text-2xl text-lavender-300">✦</span></div><p className="text-xs font-bold uppercase tracking-[.22em] text-lavender-300">Let’s build something meaningful</p><h3 className="mt-3 max-w-sm font-heading text-3xl font-bold leading-tight">Your next digital step starts here.</h3><a href="#contact" className="mt-8 inline-flex items-center rounded-full bg-white px-5 py-3 text-sm font-bold text-lavender-900">Talk to Fornex ↗</a></div></div></div></section>

        <section id="faq" className="bg-lavender-50/70 py-24 sm:py-28"><div className="container-width max-w-4xl"><SectionHeading eyebrow="FAQ" title="A few things you might want to know." desc="Still have a question? Send us a message and we’ll be happy to help." center/><div className="divide-y divide-lavender-200 border-y border-lavender-200">{faqs.map(([q,a],i)=><div key={q} className="py-5"><button onClick={()=>setOpenFaq(openFaq===i?-1:i)} className="flex w-full items-center justify-between gap-5 text-left font-heading text-base font-bold text-lavender-900 sm:text-lg"><span>{q}</span><span className={`text-xl text-lavender-600 transition ${openFaq===i?"rotate-180":""}`}>⌄</span></button>{openFaq===i&&<p className="max-w-3xl pt-4 text-sm leading-7 text-slate-600">{a}</p>}</div>)}</div></div></section>

        <section id="contact" className="py-24 sm:py-28"><div className="container-width grid gap-12 lg:grid-cols-[.85fr_1.15fr]"><div><SectionHeading eyebrow="Start a conversation" title="Let’s discuss your project." desc="Tell us what you’re planning. We’ll get back to you with questions and suggested next steps."/><a href="mailto:gfornex.official@gmail.com" className="inline-flex items-center gap-3 text-base font-bold text-lavender-700 hover:text-lavender-900"><span className="grid h-11 w-11 place-items-center rounded-xl bg-lavender-100">✉</span>gfornex.official@gmail.com</a><p className="mt-5 text-sm text-slate-500">Madurai, Tamil Nadu, India</p></div>
          <form onSubmit={submitForm} className="rounded-3xl border border-lavender-100 bg-white p-6 shadow-xl shadow-lavender-100 sm:p-8"><div className="grid gap-5 sm:grid-cols-2"><label className="text-sm font-bold text-lavender-900">Your name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="mt-2 w-full rounded-xl border border-lavender-200 bg-lavender-50/60 px-4 py-3 font-normal outline-none transition focus:border-lavender-500 focus:ring-4 focus:ring-lavender-100" placeholder="Enter your name"/></label><label className="text-sm font-bold text-lavender-900">Your email<input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} className="mt-2 w-full rounded-xl border border-lavender-200 bg-lavender-50/60 px-4 py-3 font-normal outline-none transition focus:border-lavender-500 focus:ring-4 focus:ring-lavender-100" placeholder="you@example.com"/></label></div><div className="mt-6"><p className="mb-3 text-sm font-bold">What do you need?</p><div className="flex flex-wrap gap-2">{services.map(s=><button type="button" key={s.title} onClick={()=>toggleService(s.title)} className={`rounded-full border px-3.5 py-2 text-xs font-semibold transition ${selected.includes(s.title)?"border-lavender-700 bg-lavender-700 text-white":"border-lavender-200 bg-white text-slate-600 hover:border-lavender-400 hover:bg-lavender-50"}`}>{s.title}</button>)}</div></div><label className="mt-6 block text-sm font-bold text-lavender-900">Tell us about your project<textarea required rows="4" value={form.message} onChange={e=>setForm({...form,message:e.target.value})} className="mt-2 w-full resize-y rounded-xl border border-lavender-200 bg-lavender-50/60 px-4 py-3 font-normal outline-none transition focus:border-lavender-500 focus:ring-4 focus:ring-lavender-100" placeholder="A little about your idea, goals and timeline..."/></label><button type="submit" className="mt-6 inline-flex items-center rounded-full bg-lavender-700 px-7 py-3.5 text-sm font-bold text-white shadow-lg shadow-lavender-200 transition hover:-translate-y-0.5 hover:bg-lavender-800">Send enquiry →</button><p className="mt-3 text-xs text-slate-400">This opens your default email app with your enquiry prepared.</p></form>
        </div></section>
      </main>

      <footer className="bg-lavender-900 py-10 text-white"><div className="container-width flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-center"><div><Brand light/><p className="mt-3 text-xs text-lavender-200/65">Technology that moves your business forward.</p></div><div className="text-xs text-lavender-200/65">© {new Date().getFullYear()} Fornex. All rights reserved. · Madurai, Tamil Nadu</div></div></footer>
    </div>
  );
}
