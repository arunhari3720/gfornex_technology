import { Brand } from "./Header";

export default function Footer() {
  return (
    <footer className="bg-brand-900 py-10 text-white">
      <div className="container-width flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-center">
        <div><Brand /><p className="mt-3 text-xs text-brand-200/65">Technology that moves your business forward.</p></div>
        <div className="text-xs text-brand-200/65">© {new Date().getFullYear()} Fornex. All rights reserved. Madurai, Tamil Nadu</div>
      </div>
    </footer>
  );
}
