import { useState } from "react";
import { LOGO_FULL } from "../data";

export function Brand() {
  return (
    <a href="#home" className="inline-flex items-center" aria-label="Fornex IT Solutions">
      <img src={LOGO_FULL} alt="Fornex IT Solutions" className="h-9 w-auto" />
    </a>
  );
}

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const nav = [["Services", "#services"], ["Process", "#process"], ["Why Fornex", "#why"], ["FAQ", "#faq"]];

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-brand-950/90 backdrop-blur-xl">
      <div className="container-width flex h-[76px] items-center justify-between">
        <Brand />
        <nav className="hidden items-center gap-8 md:flex">
          {nav.map(([label, href]) => <a key={label} href={href} className="text-sm font-semibold text-brand-100 transition hover:text-white">{label}</a>)}
          <a href="#contact" className="rounded-full bg-brand-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-brand-900/40 transition hover:bg-brand-400">Let’s talk</a>
        </nav>
        <button onClick={() => setMenuOpen(!menuOpen)} className="rounded-xl border border-white/30 px-3 py-2 text-sm font-bold text-white md:hidden" aria-label="Toggle navigation">{menuOpen ? "Close" : "Menu"}</button>
      </div>
      {menuOpen && <nav className="container-width flex flex-col gap-1 pb-5 md:hidden">{[...nav, ["Contact", "#contact"]].map(([label, href]) => <a onClick={() => setMenuOpen(false)} key={label} href={href} className="rounded-xl px-3 py-3 font-semibold text-brand-100 hover:bg-white/10">{label}</a>)}</nav>}
    </header>
  );
}
