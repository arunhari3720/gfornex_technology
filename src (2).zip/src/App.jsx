import Header from "./components/Header";
import Footer from "./components/Footer";
import HeroSection from "./components/sections/HeroSection";
import AboutStory from "./components/sections/AboutStory";
import Services from "./components/sections/Services";
import Process from "./components/sections/Process";
import WhatWeBuild from "./components/sections/WhatWeBuild";
import WhyFornex from "./components/sections/WhyFornex";
import PortfolioSamples from "./components/sections/PortfolioSamples";
import Testimonials from "./components/sections/Testimonials";
import FAQ from "./components/FAQ";
import ContactForm from "./components/ContactForm";

export default function App() {
  return (
    <div className="overflow-x-clip bg-white text-brand-900">
      <Header />
      <main>
        <HeroSection />
        <AboutStory />
        <Services />
        <Process />
        <WhatWeBuild />
        <WhyFornex />
        <PortfolioSamples />
        <Testimonials />
        <FAQ />
        <ContactForm />
      </main>
      <Footer />
    </div>
  );
}
